from django.shortcuts import render

def tic_tac_toe(request):
    return render(request, 'tic_tac_toe.html')

def snack(request):
    return render(request, 'snack.html')
